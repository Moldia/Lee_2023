


import os
import pandas as pd
import tifffile
import numpy as np
import cv2
import math
import ashlar.scripts.ashlar as ashlar


def zen_formatting_mipped(exported_directory, output_directory):
    '''
    using this function is predicated on the fact that you are using the nilsson SOP for naming files. 
    '''

    import tifffile
    import os
    from os import listdir
    import pandas as pd
    import numpy as np
    from xml.dom import minidom

    # make directory
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    
    # find files
    onlyfiles = listdir(exported_directory)
    onlytifs =  [k for k in onlyfiles if '.tif' in k]
    onlyfiles_df = pd.DataFrame(onlytifs)

    onlyfiles_split_tiles = onlyfiles_df[0].str.split('m',expand=True)
    onlyfiles_split_channel = onlyfiles_split_tiles[0].str.split('_',expand=True)

    tiles = list(np.unique(onlyfiles_split_tiles[1]))
    channels = list(np.unique(onlyfiles_split_channel[2]))
    rounds = list(np.unique(onlyfiles_split_channel[1]))

    for i, round_number in enumerate(rounds):
        onlytifs_round_filt = [l for l in onlytifs if '_'+round_number+'_' in l]
        imgs = []
        for i in (tiles):
            stacked = np.empty((5, 2048, 2048))
            tile_filtered = [k for k in onlytifs_round_filt if i in k]
            for n,image_file in enumerate(tile_filtered):
                image_int = tifffile.imread(exported_directory +'/'+image_file)
                stacked[n] = image_int
            imgs.append(stacked)

        metadatafiles =  [k for k in onlyfiles if 'info.xml' in k]
        metadatafiles_filt =  [k for k in metadatafiles if '_'+round_number+'_' in k]

        for p, meta in enumerate(metadatafiles_filt):
            mydoc = minidom.parse(exported_directory +'/'+ meta)
            tile =[]
            x =[]
            y =[]
            items = mydoc.getElementsByTagName('Bounds')
            for elem in items:
                tile.append(int(elem.attributes['StartM'].value))
                x.append(float(elem.attributes['StartX'].value))
                y.append(float(elem.attributes['StartY'].value))
            unique_tiles = list(np.unique(tile))
            x_reformatted = (x[:len(unique_tiles)])    
            y_reformatted = (y[:len(unique_tiles)])     
            dictionary = {'x': x_reformatted, 'y': y_reformatted}  

            df = pd.DataFrame(dictionary) 
            positions = np.array(df).astype(int)

            pixel_size = 0.1625
            with tifffile.TiffWriter(output_directory+'/cycle_'+str(round_number)+'.ome.tif', bigtiff=True) as tif:
                for img, p in zip(imgs, positions.astype(int)):
                    metadata = {
                        'Pixels': {
                            'PhysicalSizeX': pixel_size,
                            'PhysicalSizeXUnit': 'µm',
                            'PhysicalSizeY': pixel_size,
                            'PhysicalSizeYUnit': 'µm'
                        },
                        'Plane': {
                            'PositionX': [p[0]*pixel_size]*img.shape[0],
                            'PositionY': [p[1]*pixel_size]*img.shape[0]
                        }

                    }
                    tif.write(img.astype('uint16'), metadata=metadata)

# TODO: create the leica 

def leica_formatting_mipped(exported_directory, output_directory):
    '''
    using this function is predicated on the fact that you are using the nilsson SOP for naming files. 
    '''

    import tifffile
    import os
    from os import listdir
    import pandas as pd
    import numpy as np
    from xml.dom import minidom

    # make directory
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    
    # find files
    onlyfiles = listdir(exported_directory)
    onlytifs =  [k for k in onlyfiles if '.tif' in k]
    onlyfiles_df = pd.DataFrame(onlytifs)

    onlyfiles_split_tiles = onlyfiles_df[0].str.split('m',expand=True)
    onlyfiles_split_channel = onlyfiles_split_tiles[0].str.split('_',expand=True)

    tiles = list(np.unique(onlyfiles_split_tiles[1]))
    channels = list(np.unique(onlyfiles_split_channel[2]))
    rounds = list(np.unique(onlyfiles_split_channel[1]))

    for i, round_number in enumerate(rounds):
        onlytifs_round_filt = [l for l in onlytifs if '_'+round_number+'_' in l]
        imgs = []
        for i in (tiles):
            stacked = np.empty((5, 2048, 2048))
            tile_filtered = [k for k in onlytifs_round_filt if i in k]
            for n,image_file in enumerate(tile_filtered):
                image_int = tifffile.imread(exported_directory +'/'+image_file)
                stacked[n] = image_int
            imgs.append(stacked)

        metadatafiles =  [k for k in onlyfiles if 'info.xml' in k]
        metadatafiles_filt =  [k for k in metadatafiles if '_'+round_number+'_' in k]

        for p, meta in enumerate(metadatafiles_filt):
            mydoc = minidom.parse(exported_directory +'/'+ meta)
            tile =[]
            x =[]
            y =[]
            items = mydoc.getElementsByTagName('Bounds')
            for elem in items:
                tile.append(int(elem.attributes['StartM'].value))
                x.append(float(elem.attributes['StartX'].value))
                y.append(float(elem.attributes['StartY'].value))
            unique_tiles = list(np.unique(tile))
            x_reformatted = (x[:len(unique_tiles)])    
            y_reformatted = (y[:len(unique_tiles)])     
            dictionary = {'x': x_reformatted, 'y': y_reformatted}  

            df = pd.DataFrame(dictionary) 
            positions = np.array(df).astype(int)

            pixel_size = 0.1625
            with tifffile.TiffWriter(output_directory+'/cycle_'+str(round_number)+'.ome.tif', bigtiff=True) as tif:
                for img, p in zip(imgs, positions.astype(int)):
                    metadata = {
                        'Pixels': {
                            'PhysicalSizeX': pixel_size,
                            'PhysicalSizeXUnit': 'µm',
                            'PhysicalSizeY': pixel_size,
                            'PhysicalSizeYUnit': 'µm'
                        },
                        'Plane': {
                            'PositionX': [p[0]*pixel_size]*img.shape[0],
                            'PositionY': [p[1]*pixel_size]*img.shape[0]
                        }

                    }
                    tif.write(img.astype('uint16'), metadata=metadata)

    
## TODO
'''
make leica formatting function
'''

import ashlar.scripts.ashlar as ashlar
import pathlib
import warnings
warnings.filterwarnings("ignore")
def ashlar_wrapper(
    files, 
    output='', 
    align_channel=1, 
    flip_x=False, 
    flip_y=True, 
    output_channels=None, 
    maximum_shift=500, 
    filter_sigma=5.0, 
    filename_format='Round{cycle}_{channel}.tif',
    pyramid=False,
    tile_size=None,
    ffp=False,
    dfp=False,
    plates=False,
    quiet=False,
    version=False):

    ashlar.configure_terminal()
    
    filepaths = files
    output_path = pathlib.Path(output)

    import warnings
    warnings.filterwarnings("ignore")   

    if not output_path.exists():
        ashlar.print_error("Output directory '{}' does not exist".format(output_path))
        return 1

    if tile_size and not pyramid:
        ashlar.print_error("--tile-size can only be used with --pyramid")
        return 1
    if tile_size is None:
        # Implement default value logic as mentioned in argparser setup above.
        tile_size = tile_size

    ffp_paths = ffp
    if ffp_paths:
        if len(ffp_paths) not in (0, 1, len(filepaths)):
            ashlar.print_error(
                "Wrong number of flat-field profiles. Must be 1, or {}"
                " (number of input files)".format(len(filepaths))
            )
            return 1
        if len(ffp_paths) == 1:
            ffp_paths = ffp_paths * len(filepaths)

    dfp_paths = dfp
    if dfp_paths:
        if len(dfp_paths) not in (0, 1, len(filepaths)):
            ashlar.print_error(
                "Wrong number of dark-field profiles. Must be 1, or {}"
                " (number of input files)".format(len(filepaths))
            )
            return 1
        if len(dfp_paths) == 1:
            dfp_paths = dfp_paths * len(filepaths)

    aligner_args = {}
    aligner_args['channel'] = align_channel
    aligner_args['verbose'] = not quiet
    aligner_args['max_shift'] = maximum_shift
    aligner_args['filter_sigma'] = filter_sigma

    mosaic_args = {}
    if output_channels:
        mosaic_args['channels'] = output_channels
    if pyramid:
        mosaic_args['tile_size'] = tile_size
    if quiet is False:
        mosaic_args['verbose'] = True

    try:
        if plates:
            return ashlar.process_plates(
                filepaths, output_path, filename_format, flip_x,
                flip_y, ffp_paths, dfp_paths, aligner_args, mosaic_args,
                pyramid, quiet
            )
        else:
            mosaic_path_format = str(output_path / filename_format)
            return ashlar.process_single(
                filepaths, mosaic_path_format, flip_x, flip_y,
                ffp_paths, dfp_paths, aligner_args, mosaic_args, pyramid,
                quiet
            )
    except ashlar.ProcessingError as e:
        ashlar.print_error(str(e))
        return 1

def reshape_split(image: np.ndarray, kernel_size: tuple):
        
    img_height, img_width = image.shape
    tile_height, tile_width = kernel_size
    
    tiled_array = image.reshape(img_height // tile_height, 
                               tile_height, 
                               img_width // tile_width, 
                               tile_width)
    
    tiled_array = tiled_array.swapaxes(1,2)
    return tiled_array

def tile_stitched_images(image_path,outpath, tile_dim=2000):
    """
    used to tile stitched images
    
    input the directory to the files that you want to tile. 
    
    """
    if not os.path.exists(outpath):
            os.makedirs(outpath)
            
    images = os.listdir(image_path)
    for image_file in images:
        image = tifffile.imread(image_path +'/'+ image_file)
        
        cycle = ''.join(filter(str.isdigit, image_file.split('_')[0]))
        channel = ''.join(filter(str.isdigit, image_file.split('_')[1]))
        print('tiling: ' + image_file)
        
        image_pad = cv2.copyMakeBorder( image, top = 0, bottom =math.ceil(image.shape[0]/tile_dim)*tile_dim-image.shape[0], left =0, right = math.ceil(image.shape[1]/tile_dim)*tile_dim-image.shape[1], borderType = cv2.BORDER_CONSTANT)
        image_split = reshape_split(image_pad,(tile_dim,tile_dim))
        nrows, ncols, dim1, dim2 = image_split.shape
        x = []
        y = []
        directory = outpath +'/'+'Base_'+str(int(cycle)+1)+'_stitched-'+str(int(channel)+1) 
        if not os.path.exists(directory):
            os.makedirs(directory) 
        count = 0
        for i in range(nrows):
            for j in range(ncols):
                count = count+1                
                x.append(j*tile_dim)
                y.append(i*tile_dim)
                
                tifffile.imwrite(directory + '/' +'tile'+str(count)+'.tif',image_split[i][j])
                
    tile_pos = pd.DataFrame()
    tile_pos['x'] = x
    tile_pos['y'] = y


    tile_pos.to_csv(outpath+'/'+'tilepos.csv', header=False, index=False)
    return
